# This file only exists for backwards compatibility.
from comfy_api.latest._input_impl import VideoFromFile, VideoFromComponents

__all__ = [
    "VideoFromFile",
    "VideoFromComponents",
]
