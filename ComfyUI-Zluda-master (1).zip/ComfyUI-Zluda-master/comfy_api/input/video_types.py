# This file only exists for backwards compatibility.
from comfy_api.latest._input.video_types import VideoInput

__all__ = [
    "VideoInput",
]
